package ru.heldyy.hubswap.config;

import com.google.gson.annotations.Expose;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class ModConfig {
    @Expose
    private int classicDelay = 1500;
    @Expose
    private int clickDelay = 200;

    // Commands
    @Expose
    private String classicCommand = "cn";
    @Expose
    private String lightCommand = "ln";
    @Expose
    private String light120Command = "ln120";

    @Expose
    private boolean notificationsEnabled = true;

    // Цветовые настройки
    @Expose
    private ColorTheme colorTheme = ColorTheme.AQUA; // По умолчанию синий (AQUA)
    
    @Expose
    private class_124 linkColor = class_124.field_1065; // Цвет кликабельных ссылок серверов

    public int getClassicDelay() {
        return classicDelay;
    }

    public int getClickDelay() {
        return clickDelay;
    }

    public String getClassicCommand() {
        return classicCommand;
    }

    public String getLightCommand() {
        return lightCommand;
    }

    public String getLight120Command() {
        return light120Command;
    }

    public boolean isNotificationsEnabled() {
        return notificationsEnabled;
    }

    public ColorTheme getColorTheme() {
        return colorTheme;
    }

    public class_124 getLinkColor() {
        return linkColor;
    }

    public void setDelays(int classicDelay, int clickDelay) {
        this.classicDelay = Math.max(100, Math.min(5000, classicDelay));
        this.clickDelay = Math.max(50, Math.min(1000, clickDelay));
    }

    public void setCommands(String classicCommand, String lightCommand, String light120Command) {
        this.classicCommand = validateCommand(classicCommand, "cn");
        this.lightCommand = validateCommand(lightCommand, "ln");
        this.light120Command = validateCommand(light120Command, "ln120");
    }

    public void setNotificationsEnabled(boolean enabled) {
        this.notificationsEnabled = enabled;
    }

    public void setColorTheme(ColorTheme theme) {
        this.colorTheme = theme;
    }

    public void setLinkColor(class_124 color) {
        this.linkColor = color;
    }

    private String validateCommand(String command, String defaultCommand) {
        if (command == null || command.trim().isEmpty()) {
            class_310.method_1551().execute(() -> {
                if (class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().field_1724.method_7353(class_2561.method_43470("[HubSwap] Используется команда по умолчанию: " + defaultCommand), false);
                }
            });
            return defaultCommand;
        }
        String cleaned = command.trim()
                .replace("/", "")
                .replaceAll("[^a-zA-Z0-9_а-яА-ЯёЁ]", "");
        if (cleaned.length() > 10) {
            cleaned = cleaned.substring(0, 10);
            class_310.method_1551().execute(() -> {
                if (class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().field_1724.method_7353(class_2561.method_43470("[HubSwap] Команда сокращена до 10 символов"), false);
                }
            });
        }
        return cleaned.isEmpty() ? defaultCommand : cleaned;
    }

    // Enum для цветовых тем
    public enum ColorTheme {
        AQUA("Синяя", class_124.field_1075, 0x00d9ff),
        RED("Красная", class_124.field_1061, 0xff4444),
        BLUE("Голубая", class_124.field_1078, 0x5555ff),
        GREEN("Зелёная", class_124.field_1060, 0x55ff55),
        LIGHT_PURPLE("Фиолетовая", class_124.field_1076, 0xff55ff),
        GOLD("Золотая", class_124.field_1065, 0xffaa00);

        private final String displayName;
        private final class_124 formatting;
        private final int rgbColor;

        ColorTheme(String displayName, class_124 formatting, int rgbColor) {
            this.displayName = displayName;
            this.formatting = formatting;
            this.rgbColor = rgbColor;
        }

        public String getDisplayName() {
            return displayName;
        }

        public class_124 getFormatting() {
            return formatting;
        }

        public int getRgbColor() {
            return rgbColor;
        }

        public ColorTheme next() {
            ColorTheme[] values = values();
            return values[(this.ordinal() + 1) % values.length];
        }
    }
}