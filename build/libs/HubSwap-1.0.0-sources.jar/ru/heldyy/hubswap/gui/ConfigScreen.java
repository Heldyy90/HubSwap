package ru.heldyy.hubswap.gui;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import ru.heldyy.hubswap.HubSwap;
import ru.heldyy.hubswap.client.HubSwapClient;
import ru.heldyy.hubswap.config.ModConfig;

public class ConfigScreen extends class_437 {
    private final class_437 parent;
    private final ModConfig config;

    private class_342 classicDelayField;
    private class_342 clickDelayField;
    private class_342 classicCommandField;
    private class_342 lightCommandField;
    private class_342 light120CommandField;

    private boolean notificationsEnabledTmp;
    private class_4185 notificationsToggleButton;
    
    private ModConfig.ColorTheme currentTheme;
    private class_4185 themeToggleButton;
    
    private class_124 currentLinkColor;
    private class_4185 linkColorToggleButton;
    
    private class_4185 saveButton;
    private class_4185 cancelButton;
    
    private float backgroundAlpha = 0.0f;
    private float contentOffset = 20.0f;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Настройки HubSwap"));
        this.parent = parent;
        this.config = HubSwap.getConfig();
        this.currentTheme = config.getColorTheme();
        this.currentLinkColor = config.getLinkColor();
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int leftColX = centerX - 310;
        int rightColX = centerX + 10;
        int startY = 90;
        int fieldWidth = 300;
        int fieldHeight = 20;
        int spacing = 50;

        // ЛЕВАЯ КОЛОНКА - Поля ввода
        
        // Задержка /hub
        classicDelayField = new class_342(this.field_22793, leftColX, startY, fieldWidth, fieldHeight, class_2561.method_43470("Задержка /hub"));
        classicDelayField.method_1852(String.valueOf(config.getClassicDelay()));
        classicDelayField.method_1880(4);
        method_37063(classicDelayField);

        // Задержка кликов
        clickDelayField = new class_342(this.field_22793, leftColX, startY + spacing, fieldWidth, fieldHeight, class_2561.method_43470("Задержка кликов"));
        clickDelayField.method_1852(String.valueOf(config.getClickDelay()));
        clickDelayField.method_1880(4);
        method_37063(clickDelayField);

        // Команда Classic
        classicCommandField = new class_342(this.field_22793, leftColX, startY + spacing * 2, fieldWidth, fieldHeight, class_2561.method_43470("Команда классик"));
        classicCommandField.method_1852(config.getClassicCommand());
        classicCommandField.method_1880(10);
        method_37063(classicCommandField);

        // Команда Lite
        lightCommandField = new class_342(this.field_22793, leftColX, startY + spacing * 3, fieldWidth, fieldHeight, class_2561.method_43470("Команда лайт"));
        lightCommandField.method_1852(config.getLightCommand());
        lightCommandField.method_1880(10);
        method_37063(lightCommandField);

        // Команда Lite 1.20
        light120CommandField = new class_342(this.field_22793, leftColX, startY + spacing * 4, fieldWidth, fieldHeight, class_2561.method_43470("Команда лайт 1.20"));
        light120CommandField.method_1852(config.getLight120Command());
        light120CommandField.method_1880(10);
        method_37063(light120CommandField);

        // ПРАВАЯ КОЛОНКА - Кнопки настроек
        
        // Кнопка уведомлений
        notificationsEnabledTmp = config.isNotificationsEnabled();
        notificationsToggleButton = method_37063(class_4185.method_46430(
                getNotificationButtonText(),
                btn -> {
                    notificationsEnabledTmp = !notificationsEnabledTmp;
                    btn.method_25355(getNotificationButtonText());
                }
        ).method_46434(rightColX, startY, fieldWidth, fieldHeight).method_46431());

        // Кнопка цветовой темы
        themeToggleButton = method_37063(class_4185.method_46430(
                getThemeButtonText(),
                btn -> {
                    currentTheme = currentTheme.next();
                    btn.method_25355(getThemeButtonText());
                }
        ).method_46434(rightColX, startY + spacing, fieldWidth, fieldHeight).method_46431());

        // Кнопка цвета ссылок
        linkColorToggleButton = method_37063(class_4185.method_46430(
                getLinkColorButtonText(),
                btn -> {
                    currentLinkColor = nextLinkColor(currentLinkColor);
                    btn.method_25355(getLinkColorButtonText());
                }
        ).method_46434(rightColX, startY + spacing * 2, fieldWidth, fieldHeight).method_46431());

        // Кнопки действий внизу по центру
        int buttonY = this.field_22790 - 35;
        int buttonWidth = 140;
        saveButton = method_37063(class_4185.method_46430(class_2561.method_43470("✓ Сохранить"), btn -> onSave())
                .method_46434(centerX - buttonWidth - 5, buttonY, buttonWidth, fieldHeight)
                .method_46431());

        cancelButton = method_37063(class_4185.method_46430(class_2561.method_43470("✕ Отмена"), btn -> method_25419())
                .method_46434(centerX + 5, buttonY, buttonWidth, fieldHeight)
                .method_46431());
    }

    private class_2561 getNotificationButtonText() {
        if (notificationsEnabledTmp) {
            return class_2561.method_43470("🔔 Уведомления: ВКЛ").method_27692(class_124.field_1068);
        } else {
            return class_2561.method_43470("🔕 Уведомления: ВЫКЛ").method_27692(class_124.field_1068);
        }
    }

    private class_2561 getThemeButtonText() {
        return class_2561.method_43470("🎨 Тема: " + currentTheme.getDisplayName())
                .method_27692(currentTheme.getFormatting());
    }

    private class_2561 getLinkColorButtonText() {
        String colorName = getLinkColorName(currentLinkColor);
        return class_2561.method_43470("🔗 Цвет ссылок: " + colorName)
                .method_27692(currentLinkColor);
    }

    private String getLinkColorName(class_124 color) {
        if (color == class_124.field_1065) return "Золотой";
        if (color == class_124.field_1060) return "Зелёный";
        if (color == class_124.field_1054) return "Жёлтый";
        if (color == class_124.field_1075) return "Синий";
        if (color == class_124.field_1076) return "Фиолетовый";
        if (color == class_124.field_1061) return "Красный";
        return "Золотой";
    }

    private class_124 nextLinkColor(class_124 current) {
        class_124[] colors = {
            class_124.field_1065,
            class_124.field_1060,
            class_124.field_1054,
            class_124.field_1075,
            class_124.field_1076,
            class_124.field_1061
        };
        
        for (int i = 0; i < colors.length; i++) {
            if (colors[i] == current) {
                return colors[(i + 1) % colors.length];
            }
        }
        return class_124.field_1065;
    }

    private void onSave() {
        try {
            int classicDelay = Integer.parseInt(classicDelayField.method_1882());
            int clickDelay = Integer.parseInt(clickDelayField.method_1882());

            if (classicDelay < 100 || classicDelay > 5000) {
                if (field_22787 != null && field_22787.field_1724 != null) {
                    field_22787.field_1724.method_7353(class_2561.method_43470("[HubSwap] ").method_27692(currentTheme.getFormatting())
                            .method_10852(class_2561.method_43470("Ошибка: Задержка /hub должна быть от 100 до 5000 мс").method_27692(class_124.field_1061)), false);
                }
                return;
            }
            if (clickDelay < 50 || clickDelay > 1000) {
                if (field_22787 != null && field_22787.field_1724 != null) {
                    field_22787.field_1724.method_7353(class_2561.method_43470("[HubSwap] ").method_27692(currentTheme.getFormatting())
                            .method_10852(class_2561.method_43470("Ошибка: Задержка кликов должна быть от 50 до 1000 мс").method_27692(class_124.field_1061)), false);
                }
                return;
            }

            config.setDelays(classicDelay, clickDelay);
            config.setCommands(classicCommandField.method_1882(), lightCommandField.method_1882(), light120CommandField.method_1882());
            config.setNotificationsEnabled(notificationsEnabledTmp);
            config.setColorTheme(currentTheme);
            config.setLinkColor(currentLinkColor);
            HubSwap.saveConfig();

            HubSwapClient.registerConfiguredCommands();

            if (field_22787 != null && field_22787.field_1724 != null) {
                field_22787.field_1724.method_7353(class_2561.method_43470("[HubSwap] ").method_27692(currentTheme.getFormatting())
                        .method_10852(class_2561.method_43470("✓ Настройки сохранены успешно!").method_27692(class_124.field_1060)), false);
            }
            method_25419();
        } catch (NumberFormatException e) {
            if (field_22787 != null && field_22787.field_1724 != null) {
                field_22787.field_1724.method_7353(class_2561.method_43470("[HubSwap] ").method_27692(currentTheme.getFormatting())
                        .method_10852(class_2561.method_43470("Ошибка: Введите числовые значения для задержек").method_27692(class_124.field_1061)), false);
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Анимация появления
        backgroundAlpha = Math.min(1.0f, backgroundAlpha + delta * 2.0f);
        contentOffset = Math.max(0.0f, contentOffset - delta * 60.0f);

        // Градиентный фон
        renderGradientBackground(context);

        // Верхняя панель заголовка
        renderHeaderPanel(context);

        // Применяем анимацию появления
        context.method_51448().method_22903();
        context.method_51448().method_46416(0, contentOffset, 0);

        // Рендерим метки для полей
        renderLabels(context);

        // Рендерим все виджеты
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_51448().method_22909();
        
        // Нижняя линия
        renderFooterLine(context);
    }

    private void renderGradientBackground(class_332 context) {
        int colorTop = ((int) (backgroundAlpha * 200) << 24) | 0x0a0e27;
        int colorBottom = ((int) (backgroundAlpha * 220) << 24) | 0x1a1f3a;
        context.method_25296(0, 0, this.field_22789, this.field_22790, colorTop, colorBottom);
    }

    private void renderHeaderPanel(class_332 context) {
        int panelHeight = 65;
        int alpha = (int) (backgroundAlpha * 180);
        
        // Фон панели
        context.method_25296(0, 0, this.field_22789, panelHeight, alpha << 24 | 0x16213e, alpha << 24 | 0x0f1728);
        
        // Нижняя граница (с цветом темы)
        int themeColor = currentTheme.getRgbColor();
        context.method_25294(0, panelHeight - 2, this.field_22789, panelHeight, alpha << 24 | themeColor);
        
        // Заголовок
        class_2561 title = class_2561.method_43470("⚙ Настройки HubSwap").method_27695(currentTheme.getFormatting(), class_124.field_1067);
        context.method_27534(this.field_22793, title, this.field_22789 / 2, 20, 0xFFFFFF);
        
        // Подзаголовок
        class_2561 subtitle = class_2561.method_43470("Настройте команды и задержки для автоматического переключения серверов")
                .method_27692(class_124.field_1080);
        int subtitleWidth = this.field_22793.method_27525(subtitle);
        float scale = 0.75f;
        context.method_51448().method_22903();
        context.method_51448().method_46416(this.field_22789 / 2.0f, 38, 0);
        context.method_51448().method_22905(scale, scale, 1.0f);
        context.method_51439(this.field_22793, subtitle, -subtitleWidth / 2, 0, 0x999999, true);
        context.method_51448().method_22909();
    }

    private void renderLabels(class_332 context) {
        int centerX = this.field_22789 / 2;
        int leftColX = centerX - 310;
        int rightColX = centerX + 10;
        int startY = 90;
        int spacing = 50;
        int themeColor = currentTheme.getRgbColor();

        // Метки для левой колонки
        String[] leftLabels = {
                "⏱ Задержка /hub (мс)",
                "⏱ Задержка между кликами (мс)",
                "⌨ Команда для Classic",
                "⌨ Команда для Lite",
                "⌨ Команда для Lite 1.20"
        };

        String[] leftHints = {
                "Время ожидания после команды /hub (100-5000)",
                "Время между кликами в меню (50-1000)",
                "Например: cn, classic, кл",
                "Например: ln, lite, лайт",
                "Например: ln120, lite120"
        };

        for (int i = 0; i < leftLabels.length; i++) {
            int y = startY + spacing * i - 24;
            renderLabel(context, leftColX, y, 300, leftLabels[i], leftHints[i], themeColor);
        }

        // Метки для правой колонки
        String[] rightLabels = {
                "🔔 Настройки уведомлений",
                "🎨 Цветовая тема интерфейса",
                "🔗 Цвет названий серверов"
        };

        String[] rightHints = {
                "Показывать уведомления о переходе на сервер",
                "Изменяет цвет элементов интерфейса мода",
                "Цвет кликабельных названий (Anarchy, Lite-Anarchy)"
        };

        for (int i = 0; i < rightLabels.length; i++) {
            int y = startY + spacing * i - 24;
            renderLabel(context, rightColX, y, 300, rightLabels[i], rightHints[i], themeColor);
        }
    }

    private void renderLabel(class_332 context, int x, int y, int width, String label, String hint, int themeColor) {
        int alpha = (int) (backgroundAlpha * 100);
        
        // Фон метки
        context.method_25294(x - 2, y, x + width + 2, y + 18, alpha << 24 | 0x1a1f3a);
        
        // Левая акцентная линия
        context.method_25294(x - 2, y, x, y + 18, (int) (backgroundAlpha * 255) << 24 | themeColor);
        
        // Текст метки
        context.method_51439(this.field_22793, class_2561.method_43470(label).method_27692(currentTheme.getFormatting()), 
                x + 3, y + 2, themeColor, false);
        
        // Подсказка
        float scale = 0.7f;
        context.method_51448().method_22903();
        context.method_51448().method_46416(x + 3, y + 11, 0);
        context.method_51448().method_22905(scale, scale, 1.0f);
        context.method_51433(this.field_22793, hint, 0, 0, 0xCCCCCC, false);
        context.method_51448().method_22909();
    }

    private void renderFooterLine(class_332 context) {
        int footerY = this.field_22790 - 50;
        int alpha = (int) (backgroundAlpha * 200);
        int themeColor = currentTheme.getRgbColor();
        
        // Линия сверху кнопок
        context.method_25294(0, footerY, this.field_22789, footerY + 2, alpha << 24 | themeColor);
    }

    @Override
    public void method_25419() {
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }
}