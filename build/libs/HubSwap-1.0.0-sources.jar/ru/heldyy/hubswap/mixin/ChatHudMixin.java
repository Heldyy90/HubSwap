package ru.heldyy.hubswap.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import ru.heldyy.hubswap.HubSwap;
import ru.heldyy.hubswap.linkify.ServerLinkifier;

/**
 * Надёжный перенос функционала Click-Anarchy:
 * перехватываем добавление сообщений в чат и подменяем Text на "кликабельный",
 * при этом сохраняем исходные стили/цвета всего сообщения (кроме найденного совпадения).
 * 
 * Версия для Minecraft 1.20.1
 */
@Mixin(class_338.class)
public class ChatHudMixin {

    // Основной метод для 1.20.1: addMessage(Text)
    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/text/Text;)V",
            at = @At("HEAD"),
            argsOnly = true,
            require = 0
    )
    private class_2561 hubswap$linkify$1(class_2561 message) {
        return ServerLinkifier.linkify(message, HubSwap.getConfig());
    }

    // Метод с подписью сообщения для 1.19+/1.20.x
    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"),
            argsOnly = true,
            require = 0
    )
    private class_2561 hubswap$linkify$2(class_2561 message) {
        return ServerLinkifier.linkify(message, HubSwap.getConfig());
    }
}