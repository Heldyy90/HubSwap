package ru.heldyy.hubswap.linkify;

import ru.heldyy.hubswap.config.ModConfig;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

/**
 * Делает названия серверов HolyWorld кликабельными в чате/системных сообщениях,
 * НЕ ломая исходные цвета/стили строки.
 *
 * Поддерживает:
 *  Classic (cn): Anarchy, Anarchy-1, Anarchy-8, anarchy8
 *  Lite   (ln): Lite-Anarchy, Lite-Anarchy-40, lanarchy, lanarchy18
 */
public class ServerLinkifier {

    /**
     * IMPORTANT: порядок важен.
     * Сначала более специфичные варианты с числами, иначе "Lite-Anarchy-27" совпадёт как "Lite-Anarchy".
     */
    private static final Pattern PATTERN = Pattern.compile(
            "(?i)" +
                    // Lite first (with number, then without)
                    "(?<liteN>\\bLite-Anarchy-(?<liteNum>\\d+)\\b)" +
                    "|(?<lite1>\\bLite-Anarchy\\b)" +
                    // lanarchy first (with number, then without)
                    "|(?<lanN>\\blanarchy(?<lanNum>\\d+)\\b)" +
                    "|(?<lan1>\\blanarchy\\b)" +
                    // Classic: with dash number, then without dash (anarchy8), then plain
                    "|(?<clDash>(?<!lite-)\\banarchy-(?<clDashNum>\\d+)\\b)" +
                    "|(?<clN>(?<!lite-)\\banarchy(?<clNum>\\d+)\\b)" +
                    "|(?<cl1>(?<!lite-)\\banarchy\\b)"
    );

    public static class_2561 linkify(class_2561 original, ModConfig cfg) {
        if (original == null) return null;
        if (cfg == null) return original;

        // Быстрый чек: есть ли вообще совпадения в plain-строке
        String rawAll = original.getString();
        if (rawAll == null || rawAll.isEmpty()) return original;
        if (!PATTERN.matcher(rawAll).find()) return original;

        class_5250 out = class_2561.method_43473();
        final boolean[] changed = new boolean[]{false};

        // Проходим исходный Text по styled-сегментам, сохраняя все исходные цвета/форматы
        original.method_27658((style, part) -> {
            if (part == null || part.isEmpty()) return Optional.empty();

            boolean segmentChanged = appendLinkifiedPart(out, style, part, cfg);
            if (segmentChanged) changed[0] = true;

            return Optional.empty();
        }, class_2583.field_24360);

        return changed[0] ? out : original;
    }

    /**
     * Добавляет в out текст segment, заменяя совпадения на кликабельные слова,
     * сохраняя оригинальный стиль всего остального.
     */
    private static boolean appendLinkifiedPart(class_5250 out, class_2583 baseStyle, String segment, ModConfig cfg) {
        Matcher m = PATTERN.matcher(segment);
        if (!m.find()) {
            out.method_10852(class_2561.method_43470(segment).method_10862(baseStyle));
            return false;
        }

        m.reset();
        int last = 0;

        while (m.find()) {
            if (m.start() > last) {
                out.method_10852(class_2561.method_43470(segment.substring(last, m.start())).method_10862(baseStyle));
            }

            String matchedText = segment.substring(m.start(), m.end());

            boolean lite = m.group("lite1") != null || m.group("liteN") != null
                    || m.group("lan1") != null || m.group("lanN") != null;

            int serverNum = 1;
            if (m.group("liteNum") != null) serverNum = parseIntSafe(m.group("liteNum"), 1);
            else if (m.group("lanNum") != null) serverNum = parseIntSafe(m.group("lanNum"), 1);
            else if (m.group("clDashNum") != null) serverNum = parseIntSafe(m.group("clDashNum"), 1);
            else if (m.group("clNum") != null) serverNum = parseIntSafe(m.group("clNum"), 1);

            String baseCmd = lite ? cfg.getLightCommand() : cfg.getClassicCommand();
            String command = "/" + baseCmd + " " + serverNum;

            // Получаем цвет ссылок из конфига
            class_124 linkColor = cfg.getLinkColor();

            // ВАЖНО: стартуем от baseStyle (сохраняем жирность/курсив/и т.п.),
            // и меняем только то, что нужно для кликабельного слова
            class_2583 linkStyle = baseStyle
                    .method_30938(true)
                    .method_10977(linkColor)
                    .method_10958(new class_2558(class_2558.class_2559.field_11750, command))
                    .method_10949(new class_2568(class_2568.class_5247.field_24342,
                            class_2561.method_43470("Нажмите, чтобы отправить ")
                                    .method_10852(class_2561.method_43470(command).method_27692(class_124.field_1054))
                    ));

            out.method_10852(class_2561.method_43470(matchedText).method_10862(linkStyle));
            last = m.end();
        }

        if (last < segment.length()) {
            out.method_10852(class_2561.method_43470(segment.substring(last)).method_10862(baseStyle));
        }

        return true;
    }

    private static int parseIntSafe(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }
}